"""Utility functions for the bank marketing project.

This package contains helper functions for prediction processing,
data transformation, and other common tasks.
"""
