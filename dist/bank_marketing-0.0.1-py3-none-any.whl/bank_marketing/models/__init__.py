"""Models package for Bank Marketing prediction.

This package contains model implementations for predicting if a client will subscribe to a term deposit.
"""
